import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class RegisterScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final EmailController = TextEditingController();
    final PasswordController = TextEditingController();
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Column(
        children: [
          Center(child: FlutterLogo(size: 200)),
          Padding(
            padding: EdgeInsetsGeometry.all(8.0),
            child: Column(
              children: [
                TextFormField(
                  decoration: InputDecoration(hint: Text('Email')),
                  controller: EmailController,
                ),
                TextFormField(
                  style: TextStyle(),
                  controller: PasswordController,
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Volver Atras'),
                ),
                TextButton(
                  onPressed: () async {
                    final user = FirebaseAuth.instance.currentUser;
                    final credential = await FirebaseAuth.instance
                        .createUserWithEmailAndPassword(
                          email: EmailController.text,
                          password: PasswordController.text,
                        );
                  },
                  child: Text('Registro en Firebase'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
