import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Column(
        children: [
          Center(child: FlutterLogo(size: 200)),
          Padding(
            padding: EdgeInsetsGeometry.all(8.0),
            child: Column(
              children: [
                TextFormField(),
                TextFormField(),
                TextButton(
                  onPressed: () => Navigator.pushNamed(context, '/registro'),
                  child: Text('Registro en Firebase'),
                ),
                TextButton(
                  onPressed: () {},
                  child: Text('Registro en Firebase'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
