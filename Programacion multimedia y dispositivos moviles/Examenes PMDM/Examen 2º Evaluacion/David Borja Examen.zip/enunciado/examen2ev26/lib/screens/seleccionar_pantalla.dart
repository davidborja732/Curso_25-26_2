// TODO: Parte 2 - Ejercicio 3
/*
import 'package:flutter/material.dart';

class SeleccionarScreen extends StatelessWidget {
  const SeleccionarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    
    return StreamBuilder<User?>(
      // Escucha los cambios de estado de autenticacion
      stream: 
      builder: (context, snapshot) {
        // Mientras se está verificando el estado:
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(child: CircularProgressIndicator.adaptive()),
          );
        }
        // Si hay un error
        if (snapshot.hasError) {
          return Scaffold(
            body: Center(child: Text('Error: ${snapshot.error}')),
          );
        }
        // Si el usuario está logueado
        if (snapshot.hasData) {
          
        }
        // No hay usuario logueado
        
      },
    );
  }
}
*/
