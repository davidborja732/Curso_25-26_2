import 'package:flutter/material.dart';

class FormularioScreen extends StatefulWidget {
  const FormularioScreen({super.key});

  @override
  State<FormularioScreen> createState() => _FormularioScreenState();
}

class _FormularioScreenState extends State<FormularioScreen> {
  // TODO: Parte 6 - Ejercicio 1
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}