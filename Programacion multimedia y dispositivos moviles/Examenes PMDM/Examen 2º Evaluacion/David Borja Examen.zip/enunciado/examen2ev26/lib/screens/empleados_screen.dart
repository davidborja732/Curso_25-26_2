import 'package:flutter/material.dart';

class EmpleadosScreen extends StatefulWidget {
  const EmpleadosScreen({super.key});

  @override
  State<EmpleadosScreen> createState() => _EmpleadosScreenState();
}

class _EmpleadosScreenState extends State<EmpleadosScreen> {
  // TODO: Parte 5
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
