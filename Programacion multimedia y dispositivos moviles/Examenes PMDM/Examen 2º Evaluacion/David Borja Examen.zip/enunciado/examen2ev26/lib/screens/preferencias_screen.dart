import 'package:flutter/material.dart';
// TODO: Parte 7 - Ejercicio 1
class PreferenciasScreen extends StatelessWidget {
  const PreferenciasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
