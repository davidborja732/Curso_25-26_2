import 'package:flutter/material.dart';
// TODO: Parte 6 - Ejercicio 2
class ResultadoScreen extends StatelessWidget {
  const ResultadoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}