class Preferencias {
  // TODO: Parte 7 - Ejercicio 2
  // static late SharedPreferences _prefs;
}
