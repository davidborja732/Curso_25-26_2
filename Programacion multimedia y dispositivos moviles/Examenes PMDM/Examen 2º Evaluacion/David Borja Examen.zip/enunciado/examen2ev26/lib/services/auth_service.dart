class AuthService {
  // TODO: Parte 2 - Ejercicio 2
}