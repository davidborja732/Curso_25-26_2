// TODO: Parte 4 - Ejercicio 2
class PeliculasService {
  // Obtengo la lista de peliculas del API: https://devsapihub.com/api-movies
}
// FIN TODO: Parte 4 - Ejercicio 2