import 'package:examen2ev26/screens/login_screen.dart';
import 'package:examen2ev26/screens/register_screen.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        '/': (context) => LoginScreen(),
        '/registro': (context) => RegisterScreen(),
        //'/home': (context) => HomeScreen(),
      },

      // FIN TODO: 1ª Parte
    );
  }
}
