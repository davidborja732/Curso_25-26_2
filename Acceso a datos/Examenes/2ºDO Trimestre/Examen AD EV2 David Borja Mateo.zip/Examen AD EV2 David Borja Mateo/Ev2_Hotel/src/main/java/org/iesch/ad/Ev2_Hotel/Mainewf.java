package org.iesch.ad.Ev2_Hotel;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static java.time.LocalDateTime.*;

public class Mainewf {
    public static void main(String[] args) {
        boolean horasdifreencia;
        LocalDateTime diaactual=LocalDateTime.now();
        LocalDateTime diausu=LocalDateTime.parse("2026-02-12T19:50:12.104197800");
        if (diaactual.getYear()==diausu.getYear()&&diaactual.getYear()<=diausu.getYear()){
            System.out.println("primer if entrado");
            if (diaactual.getMonth().getValue()==diausu.getMonth().getValue()&&diaactual.getMonth().getValue()<=diausu.getMonth().getValue()){
                System.out.println("segundo if entrado");
                System.out.println(diaactual.getDayOfMonth());
                System.out.println(diausu.getDayOfMonth());
                if (diaactual.getDayOfMonth()<=diausu.getDayOfMonth()){
                    System.out.println("tercer if entrado");
                    System.out.println(String.valueOf(diaactual));
                    if (diaactual.getHour()-diausu.getHour()>=24){
                        System.out.println(diaactual.getHour()-diausu.getHour());
                    }else {
                        System.out.println("Menos de 24 horas");
                    }
                }
            }
        }


    }
}
