package org.iesch.ad.Ev2_Hotel.services;

import org.iesch.ad.Ev2_Hotel.modelo.Reserva;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;

@Service
public interface ReservasService extends MongoRepository<Reserva, String> {
}
