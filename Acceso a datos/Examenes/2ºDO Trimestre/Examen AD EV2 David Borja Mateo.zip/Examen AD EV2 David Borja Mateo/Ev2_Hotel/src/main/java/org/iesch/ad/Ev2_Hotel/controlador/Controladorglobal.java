package org.iesch.ad.Ev2_Hotel.controlador;

import org.iesch.ad.Ev2_Hotel.modelo.Reserva;
import org.iesch.ad.Ev2_Hotel.services.ReservasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controladorglobal {
    @Autowired
    ReservasService reservasService;

    @PostMapping("/api/reservas")
    public ResponseEntity<Reserva> crearReserva(@RequestBody Reserva reserva){

        return ResponseEntity.ok(reservasService.save(reserva));
    }


}
