import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import static java.nio.file.StandardCopyOption.ATOMIC_MOVE;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;


public class Ejercicio_1 {


    public static void CrearCarpeta(File carpeta){
        if (!carpeta.exists()){
            try {
                Files.createDirectory(carpeta.toPath());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else {
            System.out.println("Existe "+carpeta);
        }
    }
    public static void main(String[] args) {

        File carpetaCurrent =new File("Current");
        File carpetaArchive =new File("Archive");
        File carpetaWorkingdirt =new File("Workingdir");
        CrearCarpeta(carpetaCurrent);
        CrearCarpeta(carpetaArchive);
        List<File> archivosWorking= List.of(carpetaWorkingdirt.listFiles());
        /*for (int i = 0; i < archivosWorking.size(); i++) {
            System.out.println(archivosWorking.get(i));
        }*/
        List<File> archivosWorkingOrdenados=archivosWorking.stream().sorted((o1, o2) -> o2.compareTo(o1)).toList();
        for (int i = 0; i < archivosWorking.size(); i++) {
            System.out.println(archivosWorking.get(i));
            if (i==0){
                try {
                    Files.move(archivosWorkingOrdenados.get(i).toPath(),carpetaCurrent.toPath(),ATOMIC_MOVE);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }else {
                try {
                    Files.move(archivosWorkingOrdenados.get(i).toPath(),carpetaArchive.toPath(),ATOMIC_MOVE);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }


    }

}

